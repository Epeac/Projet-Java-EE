package com.todo;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class TodoDBUtil {
    private DataSource dataSource;

    public TodoDBUtil(DataSource theDataSource) {
        dataSource = theDataSource;
    }
    public List<Todo> getTodo() throws Exception {
        List<Todo> todo= new ArrayList<Todo>();
        Connection myConn=null;
        Statement myStmt = null;
        ResultSet myRs= null;
        try {
            myConn = dataSource.getConnection();
            myStmt= myConn.createStatement();
            String sql= "select * from todo";
            myRs = myStmt.executeQuery(sql);
            while(myRs.next()){
                int id = myRs.getInt("id");
                String tododescription=myRs.getString("tododescription");
                Todo tempTodo= new Todo(id,tododescription);
                todo.add(tempTodo);
            }
            return todo;
        } finally{
            close(myConn,myStmt,myRs);
        }
    }
    private void close(Connection myConn, Statement myStmt, ResultSet myRs) {
        try{
            if(myStmt!=null)
                myStmt.close();
            if(myRs!=null)
                myRs.close();
            if(myConn!=null)
                myConn.close();
        }catch(Exception e){
            System.out.println(e.getMessage());
        }
    }
    public Todo fetchTodo(int id) {
        Connection myConn=null;
        Statement myStmt = null;
        ResultSet myRs= null;
        Todo todo=null;
        try {
            myConn = dataSource.getConnection();
            myStmt= myConn.createStatement();
            String sql= "select * from todo where id="+id;
            myRs = myStmt.executeQuery(sql);
            while(myRs.next()){
                String tododescription=myRs.getString("tododescription");
                todo = new Todo(id, tododescription);
            }
            return todo;
        }catch(Exception e){
            System.out.println(e.getMessage());
            return null;
        } finally{
            close(myConn,myStmt,myRs);
        }
    }

    public void addTodo(Todo todo) {
        Connection myConn=null;
        PreparedStatement myStmt = null;
        try {
            myConn = dataSource.getConnection();
            String sql = "insert into todo values(?,?)";
            myStmt = myConn.prepareStatement(sql);
            myStmt.setInt(1,todo.getId());
            myStmt.setString(2, todo.getTododescription());
            myStmt.execute();
        }
        catch(Exception e){
            System.out.println(e.getMessage());
        }
        finally{
            close(myConn,myStmt,null);
        }
    }
    public void updateTodo(Todo todo) {
        Connection myConn=null;
        PreparedStatement myStmt = null;
        try {
            myConn = dataSource.getConnection();
            String sql = "update todo set tododescription=? where id=?";
            myStmt = myConn.prepareStatement(sql);
            myStmt.setString(1, todo.getTododescription());
            myStmt.setInt(2,todo.getId());
            myStmt.execute();
        }
        catch(Exception e){
            System.out.println(e.getMessage());
        }
        finally{
            close(myConn,myStmt,null);
        }
    }
    public void deleteTodo(Todo todo) {
        Connection myConn=null;
        PreparedStatement myStmt = null;
        try {
            myConn = dataSource.getConnection();
            String sql = "delete from todo where id=?";
            myStmt = myConn.prepareStatement(sql);
            myStmt.setInt(1,todo.getId());
            myStmt.execute();
        }
        catch(Exception e){
            System.out.println(e.getMessage());
        }
        finally{
            close(myConn,myStmt,null);
        }
    }



}