package com.todo;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

public class AuthentificationDBUtil {
    private DataSource dataSource;

    public AuthentificationDBUtil(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    public User trouverutilisateur(String username, String password) {
        Connection myConn =null;
        Statement myStmt =null;
        ResultSet myRs =null;
        User user = null;
        try{
            myConn = dataSource.getConnection();
            myStmt = myConn.createStatement();
            String sql = "Select * from users where username ='"+username+"' and password ='"+password+"'";
            myRs = myStmt.executeQuery(sql);
            while(myRs.next()){
                String role = myRs.getString("role");
                user = new User(username,password,role);
            }
            return user;
        }catch(Exception e){
            System.out.println(e.getMessage());
            return null;
        }finally {
            close(myConn,myStmt,myRs);
        }
    }
    private void close(Connection myConn, Statement myStmt, ResultSet myRs) {
        try{
            if(myStmt!=null)
                myStmt.close();
            if(myRs!=null)
                myRs.close();
            if(myConn!=null)
                myConn.close();
        }catch(Exception e){
            System.out.println(e.getMessage());
        }
    }
}