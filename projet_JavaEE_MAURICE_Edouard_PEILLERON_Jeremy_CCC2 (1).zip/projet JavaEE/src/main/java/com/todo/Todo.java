package com.todo;

public class Todo {
    int id;
    String tododescription;

    public Todo(int id, String tododescription) {
        this.id = id;
        this.tododescription = tododescription;
    }

    public Todo(String tododescription) {
        this.id=0;
        this.tododescription = tododescription;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTododescription() {
        return tododescription;
    }

    public void setTododescription(String tododescription) {
        this.tododescription = tododescription;
    }

    @Override
    public String toString() {
        return "Todo{" +
                "id=" + id +
                ", tododescription='" + tododescription + '\'' +
                '}';
    }
}
