package com.todo;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;
import java.io.IOException;

@WebServlet("/EditTodoServlet")
public class EditTodoServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private TodoDBUtil todoDBUtil;
    private DataSource dataSource;
    int id;
    private DataSource getDataSource() throws NamingException {
        String jndi="java:comp/env/jdbc/tododb" ;
        Context context = new InitialContext();
        DataSource dataSource = (DataSource) context.lookup(jndi);
        return dataSource;
    }
    @Override
    public void init() throws ServletException {
// TODO Auto-generated method stub
        super.init();
        try {
            this.dataSource= getDataSource();
            todoDBUtil = new TodoDBUtil(dataSource);
        } catch (NamingException e) {
            e.printStackTrace();
        }
    }
    public EditTodoServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        id=Integer.parseInt(request.getParameter("todoId"));
        Todo todo= todoDBUtil.fetchTodo(id);
        request.setAttribute("Todo", todo);
        request.getRequestDispatcher("edit-todo.jsp").forward(request, response);
    }



    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws
            ServletException, IOException {
        String tododescription= request.getParameter("tododescription");
        Todo todo = new Todo(id,tododescription);
        todoDBUtil.updateTodo(todo);
        response.sendRedirect("TodoControllerServlet");
    }

}
