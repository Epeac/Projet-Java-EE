package com.todo;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import javax.sql.DataSource;
import java.io.IOException;

;

@WebServlet(name = "AuthentificationServlet", value = "/AuthentificationServlet")
public class AuthentificationServlet extends HttpServlet {
    private DataSource dataSource;
    private AuthentificationDBUtil authentificationDBUtil;

    public AuthentificationServlet() {
        super();
    }

    private DataSource getDataSource() throws NamingException {
        String jndi = "java:comp/env/jdbc/tododb";
        Context context = new InitialContext();
        DataSource dataSource = (DataSource) context.lookup(jndi);
        return dataSource;
    }

    @Override
    public void init() throws ServletException {
        super.init();
        try {
            dataSource = getDataSource();
            authentificationDBUtil = new AuthentificationDBUtil(dataSource);
        } catch (NamingException e) {
            e.printStackTrace();
        }

    }


    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.getRequestDispatcher("/login.jsp").forward(request, response);
    }
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String name = request.getParameter("username");
        String mdp = request.getParameter("password");
        try{
            User user = authentificationDBUtil.trouverutilisateur(name.toLowerCase(),mdp);

            Cookie crunch = new Cookie("username",name);
            crunch.setMaxAge(60*60*50);
            response.addCookie(crunch);

            HttpSession actualsession = request.getSession();
            actualsession.setAttribute("username",user.getUsername());
            actualsession.setAttribute("role",user.getRole());
            if(user.getRole()=="not found"){
                throw new Exception("Utilisateur pas trouvé");
            }
            response.sendRedirect("TodoControllerServlet");
        }catch(Exception e) {
            request.getRequestDispatcher("login-fail.jsp").forward(request, response);
        }

    }

}